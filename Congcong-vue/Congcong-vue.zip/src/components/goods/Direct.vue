<template>
  <!-- 直营标签 -->
  <div>
    <span class="goods-item-name-direct">直营</span>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
@import "@css/style.scss";
.goods-item-name-direct {
  padding: 0 pa2rem(4);
  margin-right: px2rem(4);
  font-size: $minInfoSize;
  color: white;
  background-color: $mainColor;
  border-radius: px2rem(2);
  margin-top: px2rem(2);
}
</style>
